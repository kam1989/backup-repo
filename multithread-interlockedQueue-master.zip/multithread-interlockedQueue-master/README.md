# multithread-interlockedQueue

class hazard

support dequeue.

use hazard pointer. for concurrent problem and faster interlocked.

--------------------
class objpool

just raw new delete. disabled pool code.

----------------
class QueueT

concurrent enqueue, dequeue. 

fixed thread number can be replaced by interlockedIncrement or interlocked functions + linked list

------------------

QueueT::void Enqueue

interlockedCompareExchange -> interlockedExchange

really fast push. 

----------------------

QueueT::bool Dequeue(only return true now)

interlockedCompareExchange128 -> hazard + interlockedCompareExchange.

so little more fast. 

(https://en.wikipedia.org/wiki/Hazard_pointer)


