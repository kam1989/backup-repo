#pragma once
#include <Windows.h>
#include <iostream>
#include <queue>
#include <thread>

#include <string>
#include "interlockedQueue_noMultiOut.hpp"


void inqueue(QueueT_noMultiOut<char*>* queueP , char* data , int dataSize) {
	int count = 0;
	LARGE_INTEGER startCount;
	LARGE_INTEGER endCount;
	std::string profile;
	QueryPerformanceCounter(&startCount);
	for (count = 0; count < dataSize; count++) {
		queueP->Enqueue(&(data[count]));
	}
	QueryPerformanceCounter(&endCount);
	profile.append("insert :");
	profile.append(std::to_string((endCount.QuadPart - startCount.QuadPart)));
	profile.append("\n");
	std::cout << profile;
	return;
}

void dequeue(QueueT_noMultiOut<char*>* queueP , int totalSize) {
	char* temp = NULL;
	int count = 0;
	LARGE_INTEGER startCount;
	LARGE_INTEGER endCount;
	std::string profile;
	QueryPerformanceCounter(&startCount);
	for (count = 0; count < totalSize; count) {
		if (queueP->Dequeue_noMulti(&temp)) {
			*temp = *temp - 1;
			count++;
		};
	}

	QueryPerformanceCounter(&endCount);

	if (!queueP->checkEmpty()) {
		profile.append("wtf? not empty?\n");
	}

	profile.append(std::to_string((endCount.QuadPart - startCount.QuadPart)));
	profile.append("\n");
	std::cout << profile;
	return;
}


int main() {
	int dataSize = 1000000;
	int dataSetSize = 4;
	int count1 = 0;
	int count2 = 0;


	QueueT_noMultiOut<char*> testQueue = QueueT_noMultiOut<char*>();

	char** a = new char*[dataSetSize];
	for (count1 = 0; count1 < dataSetSize; count1++) {
		a[count1] = new char[dataSize];
		for (count2 = 0; count2 < dataSize; count2++) {
			a[count1][count2] = 1;
		}
	}

	std::thread inq0 = std::thread(inqueue, &testQueue, a[0], dataSize);
	std::thread inq1 = std::thread(inqueue, &testQueue, a[1], dataSize);
	std::thread inq2 = std::thread(inqueue, &testQueue, a[2], dataSize);
	std::thread inq3 = std::thread(inqueue, &testQueue, a[3], dataSize);

	std::thread deq = std::thread(dequeue, &testQueue, dataSetSize*dataSize);


	inq0.join();
	inq1.join();
	inq2.join();
	inq3.join();

	deq.join();


	for (count1 = 0; count1 < dataSetSize; count1++) {
		for (count2 = 0; count2 < dataSize; count2++) {
			if(a[count1][count2] != 0 ){
				printf("wtf?\n");
			}
		}
	}


	return 0;
}
