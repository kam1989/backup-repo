#pragma once
#include <Windows.h>

template<typename T>
class QueueT_noMultiOut {
public:
	QueueT_noMultiOut() {
		PushNode = new Node;
		PushNode->next = NULL;
		PushNode->dummyFlag = true;
		PopNode = PushNode;
	}

	void Enqueue(T t) {
		Node* p = new Node;
		p->data = t;
		p->next = NULL;
		p->dummyFlag = false;
		Enqueue_core(p);
	}

	bool Dequeue_noMulti(T* t) {
		volatile Node* p = NULL;
		while (true) {
			p = Dequeue_noMUlti_Core();
			if (p != NULL) {
				if (p->dummyFlag) {
					delete(p);
				}
				else {
					*t = p->data;
					delete(p);
					return true;
				}
			}
			else {
				return false;
			}
		}
	}


	bool checkEmpty() {
		//hazard pointer technique

		volatile Node* p = PushNode;

		if (PopNode->next == NULL && PopNode == PushNode && PopNode->dummyFlag) {
			if (p == PopNode) {
				return true;
			}
		}

		return false;
	}
private:
	struct Node
	{
		__declspec(align(64)) volatile Node* next;//이 노드보다 나중에 들어온 노드.
		T data;
		bool dummyFlag;
	};

	__declspec(align(64)) volatile Node* PushNode;       // 시작노드를 포인트한다.
	__declspec(align(64)) volatile Node* PopNode;        // 마지막노드를 포인트한다.

	void Enqueue_core(Node* p) {
		((Node*)InterlockedExchangePointer((PVOID*)&PushNode, (PVOID)p))->next = p;
	}

	void Enqueue_Dummy() {
		Node* p = new Node;
		p->next = NULL;
		p->dummyFlag = true;
		Enqueue_core(p);
	}

	volatile Node* Dequeue_noMUlti_Core() {
		volatile Node* p = NULL;
		while (true) {
			if (PopNode->next != NULL) {
				p = PopNode;
				PopNode = PopNode->next;
				break;
			}
			else if (PopNode->dummyFlag) {
				break;
			}
			else {
				Enqueue_Dummy();
			}
		}
		return p;
	}

};
