# multithread-interlockedQueue_noMultiOut

push to queue.

interlockedCompareExchange -> interlockedExchange

really fast push.

----

pop from queue. 

it just for single thread. there is no concurrency
